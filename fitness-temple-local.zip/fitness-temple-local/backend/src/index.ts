import app from "./app.js";

const port = Number(process.env["PORT"] ?? 3001);

app.listen(port, () => {
  console.log(`✅ Fitness Temple API server running at http://localhost:${port}`);
});

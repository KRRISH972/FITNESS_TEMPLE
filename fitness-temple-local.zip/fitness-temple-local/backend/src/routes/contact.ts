import { Router, type IRouter } from "express";
import { z } from "zod";

const router: IRouter = Router();

const BREVO_API_URL = "https://api.brevo.com/v3/smtp/email";
const GYM_EMAIL = "krrishai0916@gmail.com";

// Validation schemas (inlined from api-zod)
const SubmitContactFormBody = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  phone: z.string().min(10),
  interest: z.enum(["membership", "pt", "crossfit", "zumba"]),
  message: z.string().max(5000).optional(),
});

const SubmitContactFormResponse = z.object({
  message: z.string(),
});

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

router.post("/contact", async (req, res) => {
  const parsed = SubmitContactFormBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({
      message: "Please check the form details and try again.",
    });
    return;
  }

  const apiKey = process.env["BREVO_API_KEY"];
  if (!apiKey) {
    console.error("BREVO_API_KEY is not configured");
    res.status(503).json({
      message: "Email service is not configured. Please try again later.",
    });
    return;
  }

  const { name, email, phone, interest, message } = parsed.data;
  const interestLabel: Record<string, string> = {
    membership: "General Membership",
    pt: "Personal Training",
    crossfit: "CrossFit",
    zumba: "Zumba & Dance",
  };

  const htmlContent = [
    "<h2>New Fitness Temple contact request</h2>",
    `<p><strong>Name:</strong> ${escapeHtml(name)}</p>`,
    `<p><strong>Email:</strong> ${escapeHtml(email)}</p>`,
    `<p><strong>Phone:</strong> ${escapeHtml(phone)}</p>`,
    `<p><strong>Interest:</strong> ${escapeHtml(interestLabel[interest] ?? interest)}</p>`,
    `<p><strong>Message:</strong><br />${escapeHtml(message ?? "").replaceAll("\n", "<br />") || "No message provided."}</p>`,
  ].join("");

  try {
    const brevoResponse = await fetch(BREVO_API_URL, {
      method: "POST",
      headers: {
        accept: "application/json",
        "api-key": apiKey,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        sender: {
          email: GYM_EMAIL,
          name: "Fitness Temple Website",
        },
        to: [{ email: GYM_EMAIL, name: "Fitness Temple" }],
        replyTo: { email, name },
        subject: `New Fitness Temple contact: ${name}`,
        htmlContent,
      }),
    });

    if (!brevoResponse.ok) {
      const errorBody = await brevoResponse.text();
      console.error("Brevo rejected contact email:", brevoResponse.status, errorBody.slice(0, 500));
      res.status(503).json({
        message: "We could not send your message right now. Please try again.",
      });
      return;
    }

    const response = SubmitContactFormResponse.parse({
      message: "Your message was sent successfully.",
    });
    res.json(response);
  } catch (error) {
    console.error("Brevo request failed:", error);
    res.status(503).json({
      message: "We could not send your message right now. Please try again.",
    });
  }
});

export default router;

# 🏋️ Fitness Temple — Local Setup Guide

Gym website for **Fitness Temple, Pundri, Haryana**.  
Stack: React + Vite (frontend) · Express + Node.js (backend) · Brevo for email.

---

## 📁 Folder Structure

```
fitness-temple-local/
├── frontend/        ← React website (Vite)
├── backend/         ← Express API server (Node.js)
├── .env.example     ← Environment variable reference
└── README.md
```

---

## ⚡ Quick Start

### Prerequisites
- **Node.js** v18 or higher → https://nodejs.org
- **npm** (comes with Node.js)

---

### Step 1 — Install Dependencies

Open terminal, go into the project folder:

```bash
# Install frontend dependencies
cd frontend
npm install

# Install backend dependencies
cd ../backend
npm install
```

---

### Step 2 — Set Up Environment Variables

```bash
# Inside the backend folder
cp ../.env.example .env
```

Open `backend/.env` and add your **Brevo API Key**:

```
BREVO_API_KEY=xkeysib-your-actual-key-here
PORT=3001
```

> Get your Brevo API key from: https://app.brevo.com/settings/keys/api  
> ⚠️ Make sure `krrishai0916@gmail.com` is verified as a sender in your Brevo account.

---

### Step 3 — Run the App

You need **two terminals** open simultaneously:

**Terminal 1 — Backend (API server):**
```bash
cd backend
npm run dev
```
Server starts at → http://localhost:3001

**Terminal 2 — Frontend (Website):**
```bash
cd frontend
npm run dev
```
Website opens at → http://localhost:5173

---

## 🌐 Build for Production (Hosting)

```bash
cd frontend
npm run build
```

This creates a `frontend/dist/` folder — upload it to any static host:
- **Netlify** → drag & drop the `dist` folder at netlify.com
- **Vercel** → `vercel deploy`
- **cPanel / shared hosting** → upload `dist` contents to `public_html`

For the backend, deploy on:
- **Railway** → https://railway.app
- **Render** → https://render.com
- **VPS / any server** → run `npm run start` inside `/backend`

---

## 📧 Contact Form Setup

The contact form sends emails via **Brevo (Sendinblue)**:

1. Create free account at https://app.brevo.com
2. Go to **Senders & IPs → Add a Sender**
3. Verify `krrishai0916@gmail.com`
4. Copy your API key from **Settings → API Keys**
5. Paste it in `backend/.env`

---

## 🛠️ Pages

| Page | Route |
|------|-------|
| Home | / |
| Programs | /programs |
| About & Trainer | /about |
| Gallery | /gallery |
| Membership | /membership |
| Contact | /contact |

---

## 📞 Support

Gym: **Fitness Temple, Pundri, Haryana**  
Phone: 7206060744  
Email: krrishai0916@gmail.com
